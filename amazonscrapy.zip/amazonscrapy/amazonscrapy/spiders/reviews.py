import scrapy
from selenium.webdriver import Chrome, ChromeOptions
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys
from scrapy.selector import Selector
from scrapy.http import Request


class ReviewsSpider(scrapy.Spider):
    name = 'reviews'
    allowed_domains = ['amazon.in']
    start_urls = ['https://www.amazon.in']
    search_for_item = input('Which product would you like to scrape today? ')
    driver_path = 'C:/Users/neelkanth mehta/Documents/web_scraping_projects/amazon/chromedriver.exe'

    def start_requests(self):
        self.options = ChromeOptions()
        self.options.add_argument('headless')
        self.driver = Chrome(executable_path=self.driver_path, chrome_options=self.options)
        self.driver.get(self.start_urls[0])
        self.driver.implicitly_wait(10)
        self.driver.find_element_by_id('twotabsearchtextbox').send_keys(self.search_for_item, Keys.ENTER)
        self.driver.implicitly_wait(5)
        sel = Selector(text=self.driver.page_source)
        listing = sel.xpath('//div[@class="a-section a-spacing-medium"]')
        for item in listing:
            prodlink =  item.xpath('.//descendant::a[@class="a-link-normal a-text-normal"]/@href').get()
            prodlink = self.start_urls[0]+'/'+prodlink
            yield Request(url=prodlink, callback=self.parse_items)

        while True:
            try:
                self.driver.find_element_by_xpath('//li[@class="a-last"]/a').click()
                self.driver.implicitly_wait(5)

                sel = Selector(text=self.driver.page_source)
                listing = sel.xpath('//div[@class="a-section a-spacing-medium"]') #.extract()
                for item in listing:
                    prodlink =  item.xpath('.//descendant::a[@class="a-link-normal a-text-normal"]/@href').get()
                    prodlink = self.start_urls[0]+'/'+prodlink
                    yield Request(url=prodlink, callback=self.parse_items)
            except NoSuchElementException:
                self.logger.info('No more pages to load!')
                self.driver.quit()
                break

    def parse_items(self, response):
        '''
        parse listings
        '''
        product = response.xpath('normalize-space(//span[@id="productTitle"]/text())').get()
        price = response.xpath('//span[@id="priceblock_dealprice"]/text()').get()
        reviews_page = response.xpath('//a[@data-hook="see-all-reviews-link-foot"]/@href').get()
        if reviews_page:
            reviews_page = response.urljoin(reviews_page)
            yield Request(url=reviews_page, 
                          callback=self.parse_reviews, 
                          meta={'product': product, 'price': price}
                          )

    def parse_reviews(self, response):
        '''
        Scrape all the reviews available on that page
        '''
        product = response.meta['product']
        price = response.meta['price']
        for review in response.xpath('//div[@data-hook="review"]'):
            rating = review.xpath('.//i[@data-hook="review-star-rating"]/span/text()').get()
            review_title = review.xpath('.//a[@data-hook="review-title"]/span/text()').get()
            yield {'product': product, 
                   'price': price, 
                   'rating': rating, 
                   'review_title': review_title}

        next_page = response.xpath('//ul[@class="a-pagination"]/li[@class="a-last"]/a/@href').get()
        if next_page:
            next_page = response.urljoin(next_page)
            yield Request(url=next_page, callback=self.parse_reviews)
